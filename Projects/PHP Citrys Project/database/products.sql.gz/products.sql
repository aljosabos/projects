-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2020 at 05:38 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `comment_item_id` int(3) NOT NULL,
  `comment_title` varchar(255) NOT NULL,
  `comment_email` varchar(32) NOT NULL,
  `comment_content` varchar(500) NOT NULL,
  `comment_date` date NOT NULL,
  `comment_status` varchar(255) NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_item_id`, `comment_title`, `comment_email`, `comment_content`, `comment_date`, `comment_status`) VALUES
(10, 1, 'I like apples', 'appleboy@gmail.com', 'Just to say that i love apples so much.', '2020-02-28', 'unapproved'),
(11, 4, 'I like grapes', 'grapelover@gmail.com', 'I like to eat grapes every day.', '2020-02-28', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(3) NOT NULL,
  `item_title` varchar(255) NOT NULL,
  `item_desc` varchar(500) NOT NULL,
  `item_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_title`, `item_desc`, `item_img`) VALUES
(1, 'Apple', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum, expedita?', 'apple.jpeg'),
(2, 'Apricots', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, odit.', 'apricots.jpeg'),
(3, 'Watermelon', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, aliquid!', 'watermelon.jpeg'),
(4, 'Grapes', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, aliquid!', 'grapes.jpeg'),
(5, 'Plums', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque, laudantium.', 'plums.jpeg'),
(6, 'Pineapple', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, sint?', 'pineapple.jpeg'),
(7, 'Oranges', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus, eaque.', 'oranges.jpeg'),
(8, 'Lime', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti, iusto.', 'lime.jpeg'),
(9, 'Bananas', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, beatae.', 'bananas.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
